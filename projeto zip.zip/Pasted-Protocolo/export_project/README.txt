Este é um projeto React/Vite. Para baixar a versão estática completa, utilize a opção de Download do Replit no menu lateral.
